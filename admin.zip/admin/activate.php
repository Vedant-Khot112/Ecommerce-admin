<?php
require 'connection.inc.php';

if (isset($_GET['token'])) {
    
    $token = $_GET['token'];

    $updatequery = "UPDATE registration set status='active' where token='$token'";
    $query = mysqli_query($con,$updatequery);

    if ($query) {
        if (isset($_SESSION['msg'])) {
            $_SESSION['msg'] = "Account Updated Successfully";
            header('location:login.php');
        }else{
            $_SESSION['msg'] = "You Are Logged Out";
            header('location:login.php');
        }
    }else{
        $_SESSION['msg'] = "Account Not Updated";
        header('location:signup.php');
    
    }

}
?>