<?php
require('top.inc.php');
$categories='';
$msg='';
if(isset($_GET['id']) && $_GET['id']!=''){
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from categories where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$categories=$row['categories'];
	}else{
		?>
    <script>
      location.replace('categories.php');
    </script>
		<?php
	}
}

if(isset($_POST['submit'])){
	$categories=get_safe_value($con,$_POST['categories']);
	$res=mysqli_query($con,"select * from categories where categories='$categories'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){
			
			}else{
				$msg="Categories already exist";
			}
		}else{
			$msg="Categories already exist";
		}
	}
	
	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			mysqli_query($con,"update categories set categories='$categories' where id='$id'");
		}else{
			mysqli_query($con,"insert into categories(categories,status) values('$categories','1')");
    }
    ?>
    <script>
      location.replace('categories.php');
    </script>
		<?php
	}
}
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Category</h1>
          <a href="manage_category.php" class="btn btn-warning my-2 btn-icon-split">
                    <span class="icon text-white-50">
                    <i class="fas fa-cart-plus"></i>
                    </span>
                    <span class="text">Add Category</span>
                  </a>
                  <?php if (isset($msg) && $msg!='') {?>                  
                  <center>
          <div class="card col-lg-6 mb-4 py-1 border-left-danger">
                <div class="card-body text-danger">
                  <?php echo $msg; ?>
                </div>
              </div>
                  </center>
                  <?php } ?>
          <!-- DataTales Example -->
          <center>
          <div class="card col-lg-6 shadow mb-4">
            <div class="card-header py-3">
             <center> <h6 class="m-0 font-weight-bold text-primary">Category Form</h6></center>
            </div>
            <div class="card-body py-3">
              <form action="" style="text-align: left;"  method="post">
                <label for="">Category</label>
                <input class="form-control" type="text" placeholder="Enter Category" value="<?php echo $categories;?>" name="categories" aria-label="Category">
              
            </div>
            <div class="card-footer">
            <button name="submit" class="btn btn-info btn-icon-split">
                    <span class="icon text-white-50">
                    <i class="fas fa-save"></i>
                    </span>
                    <span class="text">Save</span>
            </button>
            </div>
            </form>
              </div>
</center>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->


<?php require 'footer.inc.php'; ?>