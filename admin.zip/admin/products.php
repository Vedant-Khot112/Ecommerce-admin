<?php require 'top.inc.php';
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='status'){
		$operation=get_safe_value($con,$_GET['operation']);
		$id=get_safe_value($con,$_GET['id']);
		if($operation=='active'){
			$status='1';
		}else{
			$status='0';
		}
		$update_status_sql="update product set status='$status' where id='$id'";
		mysqli_query($con,$update_status_sql);
	}
	
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from product where id='$id'";
		mysqli_query($con,$delete_sql);
	}
}

$sql="select product.*,categories.categories from product,categories where product.categories_id=categories.id order by product.id desc";
$res=mysqli_query($con,$sql);
?>
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Products</h1>
          <a href="manage_products.php" class="btn btn-warning my-2 btn-icon-split">
                    <span class="icon text-white-50">
                    <i class="fas fa-cart-plus"></i>
                    </span>
                    <span class="text">Add Products</span>
                  </a>
         
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Product Table</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover table-bordered table-dark table-striped " id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
							   <th>ID</th>
							   <th>Categories</th>
							   <th>Name</th>
							   <th>Image</th>
							   <th>MRP</th>
							   <th>Price</th>
							   <th>Qty</th>
                 <th>Status</th>
                 <th>Edit</th>
                 <th>Delete</th>
                 
                    </tr>
                  </thead>
                  
                  <tbody>
                      
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   
							   <td><?php echo $row['id']?></td>
							   <td><?php echo $row['categories']?></td>
							   <td><?php echo $row['name']?></td>
							   <td><img class="img-fluid" style="border-radius: 50px;" width="100"  src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']?>"/></td>
							   <td><?php echo $row['mrp']?></td>
							   <td><?php echo $row['price']?></td>
							   <td><?php echo $row['qty']?><br/>

                   
                        <style>
                            span a{
                                color: #fff;
                                text-decoration: none;
                            }
                            span a:hover{
                                 text-decoration: none;
                                 color: #ccc;
                            }
                        </style>
                      <td><?php if($row['status']==1){
                                    echo "
                                    <a href='?type=status&operation=deactive&id=".$row['id']."' class='btn btn-success btn-icon-split'>
                                    <span class='icon text-white-50'>
                                      <i class='fas fa-check'></i>
                                    </span>
                                    <span class='text'>Active</span>
                                  ";
								}else{
									echo " <a href='?type=status&operation=active&id=".$row['id']."' class='btn btn-warning btn-icon-split'>
                                    <span class='icon text-white-50'>
                                      <i class='fas fa-exclamation-triangle'></i>
                                    </span>
                                    <span class='text'>Deactive</span>
                                 ";
                                }
                                ?>
                      </td>
                                <td>
                                    <?php 
								echo "<a href='manage_categories.php?id=".$row['id']."' class='btn btn-info btn-icon-split'>
                                <span class='icon text-white-50'>
                                <i class='fas fa-edit'></i>
                                </span>
                                <span class='text'>Edit</span>
                              ";
                               ?> </td>
                               <td>
                                   <?php
								echo "  <a href='?type=delete&id=".$row['id']."' class='btn btn-danger btn-icon-split'>
                                <span class='icon text-white-50'>
                                  <i class='fas fa-trash'></i>
                                </span>
                                <span class='text'>Delete</span>
                              ";
                               ?></td>
                            
                              
                    </tr>
                      <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->


<?php require 'footer.inc.php'; ?>