<?php
require('top.inc.php');
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='status'){
		$operation=get_safe_value($con,$_GET['operation']);
		$id=get_safe_value($con,$_GET['id']);
		if($operation=='active'){
			$status='1';
		}else{
			$status='0';
		}
		$update_status_sql="update product set status='$status' $condition1 where id='$id'";
		mysqli_query($con,$update_status_sql);
	}
	
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from product where id='$id' $condition1";
		mysqli_query($con,$delete_sql);
	}
}

$sql="select product.*,categories.categories from product,categories where product.categories_id=categories.id $condition order by product.id desc";
$res=mysqli_query($con,$sql);
?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Category</h1>
          <a href="manage_category.php" class="btn btn-warning my-2 btn-icon-split">
                    <span class="icon text-white-50">
                    <i class="fas fa-cart-plus"></i>
                    </span>
                    <span class="text">Add Category</span>
                  </a>
         
          <!-- DataTales Example -->
          <center>
          <div class="card col-lg-6 shadow mb-4">
            <div class="card-header py-3">
             <center> <h6 class="m-0 font-weight-bold text-primary">Category Form</h6></center>
            </div>
            <div class="card-body py-3">
              <form action="" style="text-align: left;"  method="post">
                <label for="">Category</label>
                <input class="form-control" type="text" placeholder="Enter Category" name="categories" aria-label="deafult input example">
              
            </div>
            <div class="card-footer">
            <button name="submit" class="btn btn-info btn-icon-split">
                    <span class="icon text-white-50">
                    <i class="fas fa-save"></i>
                    </span>
                    <span class="text">Save</span>
            </button>
            </div>
            </form>
              </div>
</center>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->


<?php require 'footer.inc.php'; ?>