<?php require 'top.inc.php';?>
<style>
ul{
    text-decoration: none;
    list-style: none;
    text-align: left;
}
li{
    margin-top: 5px;
}
</style>
<div class="card text-center mx-auto" style="width: 30rem;">
 <div class="card-header">
     <h4>Profile</h4>
 </div>
 <div class="card-body">
     <div class="row">
         <div class="col-md-5">
             <ul>
                 <li>Name:-</li>
                 <li>Mobile no.:-</li>
                 <li>Email:-</li>
             </ul>
         </div>
         <div class="col-md-7">
             <ul>
                 <li><?php if(isset($_SESSION['username'])){ echo $_SESSION['username'];} ?></li>
                 <li><?php if(isset($_SESSION['mobile'])){ echo $_SESSION['mobile'];} ?></li>
                 <li><?php if(isset($_SESSION['email'])){ echo $_SESSION['email'];} ?></li>
             </ul>
         </div>
     </div>        
 </div>
 <div class="card-footer">
     <a href="#" class="btn btn-info">
         Edit
     </a>
 </div>

</div>

<?php require 'footer.inc.php'; ?>