<?php
require 'connection.inc.php';
require 'functions.inc.php';
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Forgot Password</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<?php
echo $_GET['token'];
  if (isset($_POST['submit'])) {
      if (isset($_GET['token'])) {
         echo $token = $_GET['token'];
      
    $newpassword = get_safe_value($con,$_POST['newpassword']);
    $cpassword = get_safe_value($con,$_POST['cpassword']);

    $pass = password_hash($newpassword, PASSWORD_BCRYPT);
    $cpass = password_hash($cpassword, PASSWORD_BCRYPT);
    
    $updatquery = "UPDATE registration set password='$pass' where token='$token'"; 
        if ($newpassword === $cpassword) {
         $iquery=mysqli_query($con,$updatquery);            
            if ($iquery) {
                $_SESSION['msg'] = "Password Updated Successfully";
                header('location:index.php');
            }
        else{
            $_SESSION['passworderror'] = "Password Is Not Updated";
            header('location:reset-password.php');
        }
      }else{
        $_SESSION['passworderror'] = "Password Are Not Matching";
          }
    }else{
        $_SESSION['passworderror'] = "Token Not Found";
    }
  }
  else{
      echo "no";
  }
?>

<body class="bg-gradient-primary">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-6 d-none d-lg-block bg-password-image"></div>
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-2">Update Password</h1>
                    </div>
                    <div class="text-danger my-2">
                            <p><?php 
                          if(isset($_SESSION['passworderror'])){
                            echo $_SESSION['passworderror']; 
                          }
                          else{
                            echo $_SESSION['passworderror']="";
                          }
                          ?></p>
                        </div>
                  <form class="user" action="" method="post">
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" name="newpassword" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="New Password">
                    </div>
                     <div class="form-group">
                      <input type="password" class="form-control form-control-user" name="cpassword" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Repeat Password">
                    </div>
                    <input type="submit" name="submit" value="Update Password" class="btn btn-primary btn-user btn-block">
                  </form>
                  <hr>
                  <div class="text-center">
                    <a class="small" href="signup.php">Create an Account!</a>
                  </div>
                  <div class="text-center">
                    <a class="small" href="login.php">Already have an account? Login!</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
